
function badge(s){return `<span class="badge ${s.toLowerCase()}">${s}</span>`}
async function j(u){let r=await fetch(u);return r.json()}
let trendChart,donutChart,monthlyChart,distributionChart;

async function loadDashboard(){
 const d=await j('/api/overview');
 document.getElementById('students').textContent=d.students;document.getElementById('classes').textContent=d.classes;
 document.getElementById('present').textContent=(d.present||0).toLocaleString();document.getElementById('absent').textContent=(d.absent||0).toLocaleString();
 document.getElementById('pct').textContent=d.percentage+'%';document.getElementById('donutText').textContent=d.percentage+'%';
 const t=await j('/api/trend');
 trendChart=new Chart(document.getElementById('trend'),{type:'line',data:{labels:t.map(x=>x.date.slice(5)),datasets:[{label:'Present',data:t.map(x=>x.present),borderColor:'#6d5dfc',backgroundColor:'#6d5dfc18',fill:true,tension:.3},{label:'Absent',data:t.map(x=>x.absent),borderColor:'#98a2b3',tension:.3}]},options:{plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:true}}}});
 donutChart=new Chart(document.getElementById('donut'),{type:'doughnut',data:{labels:['Present','Absent'],datasets:[{data:[d.present,d.absent],backgroundColor:['#6d5dfc','#e4e7ec'],borderWidth:0}]},options:{cutout:'78%',plugins:{legend:{display:false}}}});
}
async function loadClass(){
 const rows=await j('/api/class-prediction'); rows.sort((a,b)=>a.predicted-b.predicted);
 document.getElementById('classTable').innerHTML=`<table class="mini-table"><tr><th>Roll No</th><th>Current</th><th>Predicted</th><th>Status</th></tr>${rows.slice(0,12).map(x=>`<tr><td>${x.roll_no}</td><td>${x.current}%</td><td><b>${x.predicted}%</b></td><td>${badge(x.status)}</td></tr>`).join('')}</table>`;
}
async function loadStudentsPage(){
 const rows=await j('/api/students');const box=document.getElementById('studentTable');
 function render(a){box.innerHTML=`<table class="table"><tr><th>Roll No</th><th>Name</th><th>Present</th><th>Absent</th><th>Attendance</th><th>Status</th><th></th></tr>${a.map(x=>`<tr><td>${x.roll_no}</td><td>${x.name}</td><td>${x.present}</td><td>${x.absent}</td><td>${x.percentage}%</td><td>${badge(x.status)}</td><td><button class="btn" onclick="studentDetail('${x.roll_no}')">View</button></td></tr>`).join('')}</table>`}
 render(rows);document.getElementById('search').oninput=e=>{let q=e.target.value.toLowerCase();render(rows.filter(x=>x.roll_no.toLowerCase().includes(q)||x.name.toLowerCase().includes(q)))}
}
async function studentDetail(roll){
 const x=await j('/api/student/'+encodeURIComponent(roll));let d=document.getElementById('detail');d.style.display='block';
 d.innerHTML=`<div class="panel-head"><div><h2>${x.student.name} — ${x.student.roll_no}</h2><p>Current ${x.stats.percentage}% · Predicted ${x.prediction}%</p></div>${badge(x.prediction_status)}</div>
 <table class="table"><tr><th>Total</th><th>Present</th><th>Absent</th><th>Current</th><th>Prediction</th></tr><tr><td>${x.stats.total}</td><td>${x.stats.present}</td><td>${x.stats.absent}</td><td>${x.stats.percentage}%</td><td>${x.prediction}%</td></tr></table>
 <h3 style="font-size:13px;margin-top:18px">Attendance History</h3><table class="table"><tr><th>Date</th><th>Day</th><th>Status</th></tr>${x.history.map(r=>`<tr><td>${r.date}</td><td>${r.day}</td><td>${r.status==='P'?'Present':'Absent'}</td></tr>`).join('')}</table>`;
 d.scrollIntoView({behavior:'smooth'});
}
async function loadAnalyticsPage(){
 const d=await j('/api/analytics');
 monthlyChart=new Chart(document.getElementById('monthly'),{type:'bar',data:{labels:d.monthly.map(x=>x.month),datasets:[{label:'Attendance %',data:d.monthly.map(x=>x.percentage),backgroundColor:'#6d5dfc'}]},options:{scales:{y:{beginAtZero:true,max:100}}}});
 let bins=[0,0,0,0,0],labels=['<60%','60–69%','70–79%','80–89%','90–100%'];d.students.forEach(x=>{let p=x.percentage;bins[p<60?0:p<70?1:p<80?2:p<90?3:4]++});
 distributionChart=new Chart(document.getElementById('distribution'),{type:'bar',data:{labels,datasets:[{label:'Students',data:bins,backgroundColor:'#98a2b3'}]},options:{scales:{y:{beginAtZero:true}}}});
 document.getElementById('performance').innerHTML=`<table class="table"><tr><th>Roll</th><th>Attendance</th><th>Status</th></tr>${d.students.map(x=>`<tr><td>${x.roll_no}</td><td>${x.percentage}%</td><td>${badge(x.status)}</td></tr>`).join('')}</table>`;
}
async function loadCalendarPage(){
 const d=await j('/api/calendar');let hol=new Map(d.holidays.map(x=>[x.date,x.name]));
 document.getElementById('calendar').innerHTML=d.days.map(x=>`<div class="day ${hol.has(x.date)?'holiday':''}"><b>${x.date}</b><span>Present: ${x.present}</span><span>Absent: ${x.absent}</span><span>${Math.round(x.present/(x.present+x.absent)*100)}%</span>${hol.has(x.date)?'<span>🎉 '+hol.get(x.date)+'</span>':''}</div>`).join('');
}
